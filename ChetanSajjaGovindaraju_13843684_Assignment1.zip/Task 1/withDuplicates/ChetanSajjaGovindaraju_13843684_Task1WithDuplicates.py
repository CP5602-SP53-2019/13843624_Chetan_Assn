#Import Functions, randint for random numbers, time for time calculation , OS for File path
from random import randint
import time


#Main Function
def rNGenerator():
#Exception handler
    print ("Welcome to the Random Number Generator Program! \n")
    while (True):
        try:
#Input sequences
         n = int(input("Please enter the count of the random numbers to be generated: "))
         lowerLimit = int(input("Please enter the lower limit for the range of random numbers to be generated: "))
         upperLimit = int(input("Please enter the upper limit for the range of random numbers to be generated: "))
         break
        except:
            print("Invalid input, please try again by entering a valid numeric value")
#Inititate the list and counter
    list = []
    count = 0
#Start the timer for program runtime calculation
    startTime = time.time()
    while (count < n):
        generatedRandomNumber = randint(lowerLimit, upperLimit)
#Append the initialized list with the random number generated
        list.append(generatedRandomNumber)
        count += 1
#Present the output to the user
    print("\nThe total number of random numbers generated are: " + str(count))
    print("The random numbers generated are: ")
    print(list)
#Function to save the output to a file is called
    timeElapsed= time.time() - startTime
    saveToFile(list,timeElapsed)
#Runtime is calculated and presented
    print("Time taken to run is: " + str(timeElapsed) + " seconds")

#The sorted output is written to a file
def saveToFile(List, timeElapsed):
    
    file = open("Sorted_Lists.txt", "w+")
    file.write("[ ")
    for i in List:
        file.write(str(i) + " ")
    file.write("]")
    file.write(" " + str(timeElapsed))
    file.close()
    return
#The rNGenerator function is called
rNGenerator()
